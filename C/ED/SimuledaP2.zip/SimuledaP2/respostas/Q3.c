#include "questoes.h"
#include <stdlib.h>


TNoB* inverte(TNoB *a) {

}