#include "questoes.h"
#include <stdlib.h>

TLista* arvore_pra_lista(TNoB *a) {

}
