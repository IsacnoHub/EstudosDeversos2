#include "questoes.h"

int moda(int *vet, int tam_vet, int n) {

}
