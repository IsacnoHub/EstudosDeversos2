#include "questoes.h"
#include <stdlib.h>

// A resoluçao considera que o vetor da heap inicia em 1, como está nos slides.

int pai(int n, int indice_filho) {

}

int filho_i(int n, int indice_pai, int i) {

}

void subir(int *heap, int n, int i) {

}

void descer(int *heap, int ultimo_indice, int n, int i) {
}

int insere(int *heap, int ultimo_indice, int n, int novo) {

}

int exclui(int *heap, int ultimo_indice, int n) {

}
