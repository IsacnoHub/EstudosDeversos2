#include "questoes.h"
#include "../estruturas/hash.h"
#include <stdio.h>

void soma_k(char *arqA, char *arqB, char *saida, int k) {

}
