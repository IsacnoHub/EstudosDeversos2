#include <stdio.h>
#include "respostas/questoes.h"

int main() {
    //teste das respostas
    return 0;
}