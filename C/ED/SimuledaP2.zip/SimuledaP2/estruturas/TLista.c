#include "TLista.h"
#include <stdlib.h>

TLista* lista_inicializa() {
    return NULL;
}

TLista* lista_insere_fim(TLista *l, int valor) {
    TLista *novo = (TLista*) malloc(sizeof(TLista));
    if (novo == NULL) exit(1);

    novo->valor = valor;
    novo->prox = NULL;

    if (l == NULL) return novo;

    TLista *aux = l;
    while (aux->prox != NULL) {
        aux = aux->prox;
    }

    aux->prox = novo;

    return l;
}

TLista* lista_libera(TLista *l) {
    TLista *aux = l, *temp = NULL;

    while (aux != NULL) {
        temp = aux;
        aux = aux->prox;
        free(temp);
    }
    return NULL;
}