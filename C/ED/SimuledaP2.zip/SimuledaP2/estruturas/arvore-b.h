#ifndef ARVORE_B_ARVORE_B_H
#define ARVORE_B_ARVORE_B_H

#include <stdio.h>
#include <stdlib.h>

typedef struct No {
    int m; //quantidade de chaves armazenadas no nó
    struct No *pai;
    int *s; //array de chaves
    struct No **p; //ponteiro para array de ponteiros para os filhos
} TNoB;

TNoB *cria(int d);
TNoB *arvore_libera(TNoB *a, int d);
void arvore_imprime(TNoB *a, int nivel);
void imprime_no(TNoB *a);
int posicao(int chave, TNoB *no);
TNoB *arvore_busca(TNoB *no, int chave);
void particiona(TNoB *P, int d, int pos, int chave, TNoB *pt);
void arvore_insere(TNoB *no, int d, int pos, int chave, TNoB *pt);
TNoB *insere_folha(TNoB *raiz, int d, int chave);


#endif //ARVORE_B_ARVORE_B_H
