#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arvore-b.h"

TNoB *cria(int d) {
    TNoB *novo = (TNoB *) malloc(sizeof(TNoB));
    novo->m = 0;
    novo->pai = NULL;
    novo->s = (int *) malloc(sizeof(int *) * (d * 2));
    novo->p = (TNoB **) malloc(sizeof(TNoB *) * (d * 2) + 1);
    for (int i = 0; i < (d * 2 + 1); i++) {
        novo->p[i] = NULL;
    }
    return novo;
}

TNoB *arvore_libera(TNoB *a, int d) {
    if (a != NULL) {
        for (int i = 0; i <= d * 2 + 1; i++) {
            arvore_libera(a->p[i], d);
        }
        free(a->s);
        free(a->p);
        free(a);
    }
    return NULL;
}

/*
 * A impressao da árvore é feita como se ela estivesse na vertical ao invés da horizontal, portanto cada nó é impresso na vertical,
 * com a menor chave do nó na parte inferior do nó
 */
void arvore_imprime(TNoB *a, int nivel) {
    if (a != NULL) {
        char indent[10] = "";
        for (int i = 0; i < nivel; i++) {
            strcat(indent, "\t");
        }

        for (int i = a->m; i > 0; i--) {
            arvore_imprime(a->p[i], nivel + 1);
            printf("%s", indent);
            printf("%5d\n", a->s[i - 1]);
        }
        arvore_imprime(a->p[0], nivel + 1);
    }
}

void imprime_no(TNoB *a) {
    if (a != NULL) {
        for (int i = 0; i < a->m; i++) {
            printf("%5d", a->s[i]);
        }
        printf("\n");
    }
}

/*
 * Busca binária da posição em que a chave deveria estar dentro do nó.
 */
int posicao(int chave, TNoB *no) {
    int inicio = 0;
    int fim = no->m;
    int pos = (fim + inicio) / 2;
    while (pos != no->m && chave != no->s[pos] && inicio < fim) {
        if (chave > no->s[pos]) {
            inicio = pos + 1;
        } else {
            fim = pos;
        }
        pos = (fim + inicio) / 2;
    }
    return pos;
}

/*
 * Busca retorna ponteiro para o nó onde a chave está, ou onde ela deveria estar (se chegar numa folha e não encontrar a chave)
 */
TNoB *arvore_busca(TNoB *no, int chave) {
    int pos = posicao(chave, no);
    if (no->p[pos] == NULL || (pos < no->m && chave == no->s[pos])) {
        return no;
    } else {
        return arvore_busca(no->p[pos], chave);
    }
}

void particiona(TNoB *P, int d, int pos, int chave, TNoB *pt);

/*
 * Insere a chave e o seu repectivo ponteiro da direita (para Q) numa posição específica de um nó específico da árvore
 * d é a ordem da arvore
 * Caso a posição não seja informada (-1) o algoritmo busca pela posição correta
 * Retorna ponteiro para a raiz da árvore
 */
void arvore_insere(TNoB *no, int d, int pos, int chave, TNoB *pt) {
    if (pos == -1) {
        pos = posicao(chave, no);
    }

    if (no->m < 2 * d) { // Tem espaço no nó, então pode inserir diretamente
        for (int i = no->m; i > pos; i--) { // Abre espaço para a inserção
            no->s[i] = no->s[i - 1];
            no->p[i + 1] = no->p[i];
        }
        no->s[pos] = chave;
        no->p[pos + 1] = pt;
        if (pt != NULL) {
            pt->pai = no;
        }
        no->m++;
    } else { // Nó está cheio -- é necessário particionar
        particiona(no, d, pos, chave, pt);
    }
}

/*
 * Insere a chave numa folha da árvore
 * raiz é ponteiro para a raiz da árvore
 * d é a ordem da arvore
 * Retorna ponteiro para a raiz da árvore
 */
TNoB *insere_folha(TNoB *raiz, int d, int chave) {
    if (raiz != NULL) {
        TNoB *no = arvore_busca(raiz, chave);
        int pos = posicao(chave, no);
        if (pos == no->m || chave != no->s[pos]) { // chave não existe no nó
            arvore_insere(no, d, pos, chave, NULL);
            if (raiz->pai != NULL) { // Inserção riou uma nova raiz
                raiz = raiz->pai;
            }
        }
    } else {
        raiz = cria(d);
        raiz->s[0] = chave;
        raiz->m = 1;
    }
    return raiz;
}

/*
 * Particiona o nó P para adicionar a chave e o ponteiro pt
 * Após o final da execução dessa função, a chave terá sido inserida no local correto
 * e um novo nó Q terá sido criado como resultado do particionamento
 * Uma nova raiz W pode ser criada, se a raiz atual estiver sendo particionada
 */
void particiona(TNoB *P, int d, int pos, int chave, TNoB *pt) {
    // Prepara Q
    TNoB *Q = cria(d);
    int i = d * 2 - 1;
    int j = d - 1;
    while (j >= 0) {
        if (j != pos - d - 1) { // Move chave de P para Q
            Q->s[j] = P->s[i];
            Q->p[j + 1] = P->p[i + 1];
            i--;
        } else { // Insere chave em Q
            Q->s[j] = chave;
            Q->p[j + 1] = pt;
        }
        if (Q->p[j + 1] != NULL) {
            Q->p[j + 1]->pai = Q;
        }
        j--;
    }
    Q->m = d;

    // Processa P
    if (pos <= d) {
        P->m = d;
        arvore_insere(P, d, pos, chave, pt); // inserção vai fazer o número de chaves aumentar para d+1, e isso é tratado no final dessa função
    }

    // Processa W
    if (P->pai == NULL) { // Caso o nó seja raiz, cria o nó superior
        TNoB *W = cria(d);
        W->p[0] = P;
        P->pai = W;
    }
    // Chave d de P sobe para o pai W
    arvore_insere(P->pai, d, -1, P->s[d], Q);
    // Ajusta o ponteiro da esquerda de Q (recebe ponteiro da direita da chave que subiu para o pai W)
    Q->p[0] = P->p[d+1];
    // Se o ponteiro p[0] for diferente de NULL, ajusta o ponteiro do pai do nó apontado por p[0[
    if (Q->p[0] != NULL)
        Q->p[0]->pai = Q;
    // A inserção da chave d em W fez o número de chaves de P diminuir para D
    P->m = d;
}

int main(int argc, char *argv[]) {
    TNoB *raiz = NULL;

    int d;
    //le ordem da arvore
    printf("Digite a ordem (d) da árvore: ");
    scanf("%d", &d);

    char l[1000];
    char delimitador[] = "-";
    char *ptr;
    int valor;

    /* lê valores para criar a arvore
     * valores devem ser informados separados por traço
     * exemplo: 1-3-5-2-7-9-21-6 */
    printf("\nDigite as chaves a serem inseridas, separadas por traço (sem espaço entre os traços e os valores).\n");
    printf("Exemplo: 1-3-5-2-7-9-21-6\n");

    scanf("%s", l);
    //quebra a string de entrada
    ptr = strtok(l, delimitador);
    while(ptr != NULL) {
        valor = atoi(ptr);
        printf("\n\n*** Inserindo %d ***\n\n", valor);
        raiz = insere_folha(raiz, d, valor);
        arvore_imprime(raiz, 0);
        ptr = strtok(NULL, delimitador);
    }
    arvore_libera(raiz, d);
}

